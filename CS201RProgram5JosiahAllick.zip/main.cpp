#include <iostream>
#include <vector>
#include <string>
#include <fstream>
using namespace std;

class Employee{
  public:
    string GetName() const;
    string GetId() const;
    void SetName (const string& NewName);
    void SetId (const string& NewId);
    virtual string GetType() const;
    virtual bool ReadData(istream&) const = 0;
    virtual bool WriteData(ostream&) const = 0;
  private:
    string name = "";
    string ID = "";
};

void Employee::SetName(const string& NewName){
  name = NewName;
}

void Employee::SetId(const string &NewId){
  ID = NewId;
}

bool Employee::ReadData(istream&) const{
  string name ="", ID="";
  getline(cin, name);
  cin >> ID;
  if(name != "" && ID != ""){
    return true;
  }else{
    return false;
  }
}

bool Employee::WriteData(ostream&) const{
  cout << name << endl;
  cout << ID << endl;
  return true;
}

string Employee::GetType() const{
  return "Employee";
}

class HourlyEmployee : public Employee{
  public:
    string test = "test";
    HourlyEmployee();
    char GetExpertEmployee() const;
    double GetSalary() const;
    string GetType() const;
    bool SetExpertEmployee(char NewExpert);
    bool SetSalary(double NewSalary);
    bool ReadData(istream& input);
    bool WriteData(ostream& out);
  private:
    char experience;
    double salary;
};

HourlyEmployee::HourlyEmployee(){
  //string name = "";
  //string id = "";
  experience = 'F';
  salary = 0.0;
}

bool HourlyEmployee::ReadData(istream &input){
  //cout << "Made it" << endl;
  char theExperience;
  double theSalary;
  string name, ID;
  getline(input, name);
  input >> ID >> theExperience >> theSalary;
  Employee::SetId(ID);
  Employee::SetName(name);
  SetExpertEmployee(theExperience);
  SetSalary(theSalary);
  return input.good();
}
bool HourlyEmployee::WriteData(ostream &out){
  Employee::WriteData(out);
  out << GetExpertEmployee() << endl;
  out << GetSalary() << endl;
  return out.good();
}

string HourlyEmployee::GetType() const{
  return "Hourly Employee";
}

bool HourlyEmployee::SetExpertEmployee(char NewExpert){
  experience = NewExpert;
  if (experience == 'T'){
    return true;
  }else{
    return false;
  }
}

bool HourlyEmployee::SetSalary(double NewSalary){
  if (NewSalary >= 1000 && NewSalary <= 10000){
    salary = NewSalary;
    return true;
  }else{
    return false;
  }
}

double HourlyEmployee::GetSalary() const{
  return salary;
}

char HourlyEmployee::GetExpertEmployee() const{
  return experience;
}

class MonthlyEmployee : public Employee{
  public:
    MonthlyEmployee(string name, string ID, int rank);
    bool SetRank(int theRank);
    string GetType();
    bool ReadData(istream& input);
    bool WriteData(ostream& out) const;
  private:
    int rank = 10;
};

MonthlyEmployee::MonthlyEmployee(string name, string ID, int theRank){
  Employee::SetName(name);
  Employee::SetId(ID);
  rank = theRank;
}

string MonthlyEmployee::GetType(){
  return "Monthly Employee";
}

bool MonthlyEmployee::SetRank(int theRank){
  if (theRank > 0 && theRank < 11){
    rank = theRank;
    return true;
  }else{
    return false;
  }
}

bool MonthlyEmployee::ReadData(istream& input){
  int theRank;
  string name ="", ID="";
  getline(input, name);
  input >> ID >> theRank;
  return input.good();
}

bool MonthlyEmployee::WriteData(ostream& output) const{
  Employee::WriteData(output);
  output << rank;
  return output.good();
}

int main() {
  char type;
  Employee *theEmployee[100];
  for(int i = 0; i< 100; i++){
    theEmployee[i] = nullptr;
  }
  ifstream input;
  input.open("input.txt");
  ofstream output;
  output.open("output.txt");
  int spot = 0;
  while(input >> type){
    type =toupper(type);
    if(type == 'H'){
      HourlyEmployee *theEmployee[spot] = new HourlyEmployee;
      theEmployee[spot]->ReadData(input);
      spot += 1;
    }else if(type == 'M'){
      MonthlyEmployee *theEmployee[spot];
      //theEmployee[spot]->ReadData(input);
      //theEmployee[spot]->WriteData(output);
      spot += 1;
    }
  }
  
}